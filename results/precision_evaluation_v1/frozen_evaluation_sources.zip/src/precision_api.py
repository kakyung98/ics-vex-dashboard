"""Current precision reports and source-free operational assessment endpoints."""
from copy import deepcopy
from datetime import datetime,timezone
import json
from pathlib import Path
import uuid
from fastapi import APIRouter,HTTPException,Request
from fastapi.responses import HTMLResponse,JSONResponse
from . import operational_assessment as O,review_store

ROOT=Path(__file__).resolve().parents[1]
router=APIRouter(tags=['precision-workbench'])


def read_report(path):
    return json.loads(path.read_text(encoding='utf-8')) if path.is_file() else None


@router.get('/api/precision/metrics')
def metrics():
    return dict(item3_trained=read_report(ROOT/'results/item3_precision_v11/trained_evaluation/precision_report.json'),
        item3_rules=read_report(ROOT/'results/item3_precision_v11/rules_evaluation/precision_report.json'),
        item4_synthetic=read_report(ROOT/'results/item4_operational_v1/precision_report.json'),
        item4_trained=read_report(ROOT/'results/item4_operational_v1/trained_precision_report.json'),
        training=read_report(ROOT/'models/precision_roles_qwen25_14b_v1/status.json'),
        item3_progress=read_report(ROOT/'results/item3_precision_v11/trained_evaluation/status.json'),
        real_asset_precision=None,thresholds=dict(item3_strictly_greater_than=.8,item4_strictly_greater_than=.85))


@router.get('/api/precision/standards/attack')
def attack(asset:str='',technique:str=''):
    from .operational_standards import attack_context
    try:return attack_context([asset] if asset else [],[technique] if technique else [])
    except ValueError as exc:raise HTTPException(422,str(exc)) from exc


@router.post('/api/precision/standards/vulntology/validate')
async def native(request:Request):
    from .operational_standards import validate_native
    try:return validate_native(await body(request))
    except (ValueError,TypeError) as exc:raise HTTPException(422,str(exc)) from exc


async def body(request,limit=2*1024*1024):
    raw=await request.body()
    if len(raw)>limit:raise HTTPException(413,'Request too large')
    value=json.loads(raw)
    if not isinstance(value,dict):raise ValueError('JSON object required')
    return value


def evaluated_packet(payload,use_model=True):
    packet=deepcopy(payload['packet'])
    result=O.assess(packet)  # Server time; client cannot resurrect expired evidence.
    model=None
    if use_model and result['status']=='affected':
        from .precision_role_runtime import get_precision_runtime
        model=get_precision_runtime().operational_proposal(packet)
        if model.get('status')!='affected' or not model.get('llm_used'):
            result.update(status='under_investigation')
            result['missing_evidence'].append('trained model proposal not confirmed')
    result['model_proposal']=model
    return packet,result


@router.post('/api/precision/item4/assessments')
async def assess(request:Request):
    try:
        payload=await body(request)
        from starlette.concurrency import run_in_threadpool
        packet,result=await run_in_threadpool(evaluated_packet,payload)
        sid=uuid.uuid4().hex;result['review_id']=sid
        review_store.put('operational-context-v1',sid,dict(packet=packet,result=result))
        return result
    except (ValueError,KeyError,TypeError) as exc:raise HTTPException(422,str(exc)) from exc
    except (RuntimeError,FileNotFoundError) as exc:raise HTTPException(503,str(exc)) from exc


@router.post('/api/precision/item4/oval-results')
async def oval(request:Request):
    try:
        payload=await body(request)
        return dict(observations=O.import_oval_results(payload['xml'],payload['definition_conditions'],payload['binding'],payload['evidence']))
    except (ValueError,KeyError,TypeError) as exc:raise HTTPException(422,str(exc)) from exc


@router.post('/api/precision/item4/cves/{cve}/source-extractions',status_code=202)
async def source_extract(cve:str,request:Request):
    from .operational_source_extraction import submit
    try:
        payload=await body(request)
        return submit(cve,payload['product_key'])
    except (ValueError,KeyError,TypeError) as exc:raise HTTPException(422,str(exc)) from exc
    except OverflowError as exc:raise HTTPException(429,str(exc)) from exc
    except (OSError,RuntimeError) as exc:raise HTTPException(503,str(exc)) from exc


@router.get('/api/precision/item4/source-extractions/{identity}')
def extraction_status(identity:str):
    result=review_store.get('operational-source-job',identity)
    if not result:raise HTTPException(404,'Extraction job not found')
    return result


@router.post('/api/precision/item4/mulval-input')
async def mulval(request:Request):
    try:
        p=await body(request)
        return dict(input_P=O.mulval_input(p['binding'],p.get('network',[]),p.get('services',[]),
            p.get('vulnerabilities',[]),p['attacker_host']),
            interpretation='Attack-graph input only. No derived path never establishes non-impact.')
    except (ValueError,KeyError,TypeError) as exc:raise HTTPException(422,str(exc)) from exc


@router.post('/api/precision/item4/mulval-runs')
async def mulval_run(request:Request):
    from .operational_tool_runner import run_mulval
    try:
        payload=await body(request)
        # Docker and XSB are external work, so keep the event loop available.
        from starlette.concurrency import run_in_threadpool
        return await run_in_threadpool(run_mulval,payload)
    except (ValueError,KeyError,TypeError) as exc:raise HTTPException(422,str(exc)) from exc
    except (OSError,RuntimeError) as exc:raise HTTPException(503,str(exc)) from exc


@router.get('/api/precision/item4/assessments/{sid}/export/{kind}')
def export(sid:str,kind:str):
    saved=review_store.get('operational-context-v1',sid)
    if not saved:raise HTTPException(404,'Assessment not found')
    packet=saved['packet'];current=O.assess(packet)
    proposal=saved['result'].get('model_proposal')
    if current['status']=='affected' and (not proposal or proposal.get('status')!='affected'):
        current['status']='under_investigation'
    if current['status']!=saved['result']['status']:
        raise HTTPException(409,'Evidence validity changed; reassess before exporting')
    if kind=='review':return JSONResponse(dict(packet=packet,decision=current,model_proposal=proposal))
    if kind=='vulntology':raise HTTPException(409,'Native export requires separate source-reviewed native fields and pinned-schema validation; operational extension alone is incomplete')
    if kind!='openvex':raise HTTPException(404,'Unknown export format')
    at=datetime.now(timezone.utc).isoformat();b=packet['binding'];status=current['status']
    statement=dict(vulnerability=dict(name=b['cve']),products=[dict(**{'@id':'urn:ics-vex:asset:'+b['asset_ref']})],
        status=status,timestamp=at)
    if status=='affected':statement['action_statement']=packet['action_statement']
    elif status=='not_affected':statement['impact_statement']='Reviewed exhaustive structural nonexecution evidence for the recorded asset scope.'
    elif status=='under_investigation':statement['status_notes']='Operational evidence is incomplete or conflicting.'
    return JSONResponse({'@context':'https://openvex.dev/ns/v0.2.0','@id':'urn:uuid:'+str(uuid.uuid4()),
        'author':str(packet.get('reviewer','local ICS reviewer')),'timestamp':at,'version':1,'statements':[statement]})


@router.get('/precision.html',response_class=HTMLResponse)
def workbench():return (ROOT/'src/precision_workbench.html').read_text(encoding='utf-8')
