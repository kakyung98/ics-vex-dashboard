CycloneDX 1.7 synthetic advisory product collections, following the supplied field-definition workbook.
Products/versions: CSAF product trees and original HTML AFFECTED PRODUCTS sections. No CVE/CPE membership gate.
Ranges remain source expressions, not installed releases. BOM author and unknown free text: unknown.
No invented identifier, hash, email, license ID, dependency or device. Unknown constrained fields are marked in properties.
metadata.component is the advisory collection; components[] are product/version candidates, not a simultaneous installation.
field_mapping.json: workbook mapping. source_products.jsonl: extraction evidence. unresolved.json: incomplete sources/non-product notices.
Source conflicts/retractions keep their notes and uncertain CVE-product edges stay unknown.
Item-3 evaluation inputs/Gold/results are separate. Audit is data integrity, not field accuracy.

Whole-corpus review 2026-11-18: all files revalidated against CycloneDX 1.7; original workbook field definitions retained.
Additional source-anchored HTML corrections and explicit non-product notices are recorded in manifest.json.
Unknown-field markers reflect fields actually absent. Version expressions remain source conditions, not installed releases.

Whole-corpus review 2026-11-18: all files revalidated against CycloneDX 1.7; original workbook field definitions retained.
Additional source-anchored HTML corrections and explicit non-product notices are recorded in manifest.json.
Unknown-field markers reflect fields actually absent. Version expressions remain source conditions, not installed releases.

JSON presentation: UTF-8, two-space indentation, final newline. All 3,881 BOM documents are structurally identical to the preserved compact delivery.
